package edu.cmu.ece;

import edu.cmu.ece.config.SharedResources;
import edu.cmu.ece.helper.ConfigFileIO;
import edu.cmu.ece.helper.Constants;
import edu.cmu.ece.helper.JsonParser;
import edu.cmu.ece.services.CommandLineService;
import edu.cmu.ece.services.HeartBeatService;
import edu.cmu.ece.services.LinkStateBroadcasterService;

import java.io.File;
import java.io.IOException;

public class Contentserver {

    public static void main(String[] args) {
        try {
            String filename = Constants.CONF_FILE;
            if(args.length >= 1){
                System.out.println(args[1]);
                filename = args[1];
            }
            File configFile = new File(filename);
            if(!configFile.exists()) {
                filename = Constants.CONF_FILE;
                configFile = new File(filename);
                if(!configFile.exists()) throw new IOException("Config file does not exists");
            }

            SharedResources.setConfigFile(configFile);
            SharedResources.setServerConfig(ConfigFileIO.parseFileToConfig());
            ConfigFileIO.writeToFileConfig(SharedResources.getServerConfig());

            SharedResources.setCommandLineService(new CommandLineService());
            new Thread(SharedResources.getCommandLineService()).start();

            SharedResources.setHeartBeatService(new HeartBeatService());
            new Thread(SharedResources.getHeartBeatService()).start();

            SharedResources.setLinkStateBroadcasterService(new LinkStateBroadcasterService());
            new Thread(SharedResources.getLinkStateBroadcasterService()).start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
