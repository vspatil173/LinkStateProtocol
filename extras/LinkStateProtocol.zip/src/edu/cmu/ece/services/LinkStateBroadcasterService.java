package edu.cmu.ece.services;

import edu.cmu.ece.config.SharedResources;
import edu.cmu.ece.models.Peer;

import java.io.IOException;
import java.net.*;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class LinkStateBroadcasterService implements Runnable {

    boolean isRunning = true;
    final boolean DEBUG_MODE=true;
    final int SLEEP_TIME = 50000;
    @Override
    public void run() {
        new Thread(this::sendLinkStateMessage).start();
        new Thread(this::receiveLinkStateMessage).start();
    }

    private void sendLinkStateMessage() {
        InetAddress add = null;
        DatagramSocket dsock = null;
        try {
            dsock = new DatagramSocket();
        } catch (SocketException e) {
            System.out.println(e.getMessage());
        }

        while (isRunning) {
            try {
                //construct the mressage here and handle the updates as well
                byte[] arr = SharedResources.getServerConfig().getLinkStateMessage().toString().getBytes();
                SharedResources.getServerConfig().getLinkStateMessage().increment_Sequence_Number();

                for (int i = 0; i < SharedResources.getServerConfig().getPeers().size(); i++) {
                    Peer peer = SharedResources.getServerConfig().getPeers().get(i);
                    if (!peer.isActive()) continue;
                    add = InetAddress.getByName(peer.getIp());
                    DatagramPacket dpack = new DatagramPacket(arr, arr.length, add, peer.getPort());
                    try {
                        System.out.println("sending the message to all peers");
                        dsock.send(dpack);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Thread.sleep(SLEEP_TIME);
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            } catch (UnknownHostException e) { }
        }
    }

    private void receiveLinkStateMessage() {
        try {
            DatagramSocket dsock = new DatagramSocket(SharedResources.getServerConfig().getBackendPort());
            while (isRunning) {
                byte[] arr1 = new byte[150];
                DatagramPacket dpack = new DatagramPacket(arr1, arr1.length);
                dsock.receive(dpack);
                int packSize = dpack.getLength();
                String s2 = new String(dpack.getData(), 0, packSize);
                if(DEBUG_MODE)  System.out.println(new Date() + "  " + dpack.getAddress() + " : " + dpack.getPort() + " " + s2);
//                update the records if the sequence number is greater else ignore the message
//                if the sequence number is correct then then the message to all peers but not the original sender

                Thread.sleep((long)(SLEEP_TIME*.90));
            }
        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        }
    }

    public void killService(){
        isRunning = false;
    }
}
